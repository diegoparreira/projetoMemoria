# Projeto Final SI401 - Prog. WEB

Projeto desenvolvido ao longo do segundo semestre de 2022 para a disciplina de SI401 - Programação para WEB,
o projeto consiste em 3 entregas ao longo do semestre:

1. Front-end: toda a parte estática de front-end, com definição de layout e estilização das páginas, além de
conteúdos estáticos para preencher a página.
2. Front-end: Interações dinâmicas da página.
3. Back-end: Controle de operações no servidor.

# Links do projeto

1. [Github](https://github.com/diegoparreira/projetoMemoria)